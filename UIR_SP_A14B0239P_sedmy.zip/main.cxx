/*
	Main module of program
	Author: Martin Cervenka
	Version: 30.03.2016
*/
//#define TESTING //TODO
#include "game.h"
#include "stdmcr.h"
#include "config.h"
#include "lang.h"
#include <iostream>
using namespace std;
/*
	Main function, starts the game
*/
int main(void){
	char end;
	Configuration* conf = Configuration::GetConfiguration();
	do{
		CLEAR;
		MOVE("0;0",endl);
		Game game(conf->GetCount(),conf->GetAlgorithms());
		/*Hand* hand = game.algos[0]->hand; //TODO
		for(unsigned a=0; a<4; a++){ //TODO
			hand->Set(a,new Card(a)); //TODO
		}//TODO*/
		game.Start();
		OUT(CONTINUE);
		cin >> end;
	}while(end!=NO[0]);
	return 0;
}
