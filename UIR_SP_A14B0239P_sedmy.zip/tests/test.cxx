#include "card_test.cxx"
#include "hand_test.cxx"
#include "deck_test.cxx"
#include "algorithm_test.cxx"
#include "algono_test.cxx"
#include "game_test.cxx"
#include "person_test.cxx"
EXEC(5)
